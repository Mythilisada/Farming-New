package com.capgemini.model;
//package com.cap.entities;
//
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//
//public class Farmer {
//	@Id
//	@GeneratedValue
//	private int farmer_Id;
//	private String farmer_Name;
//	private String farmer_Email;
//	private String flag;
//	
//	
//	public Farmer(int farmer_Id, String farmer_Name, String farmer_Email, String flag) {
//		super();
//		this.farmer_Id = farmer_Id;
//		this.farmer_Name = farmer_Name;
//		this.farmer_Email = farmer_Email;
//		this.flag = flag;
//	}
//
//
//	public Farmer() {
//		super();
//	}
//
//
//
//	
//	public int getFarmer_Id() {
//		return farmer_Id;
//	}
//
//
//	public void setFarmer_Id(int farmer_Id) {
//		this.farmer_Id = farmer_Id;
//	}
//
//
//	public String getFarmer_Name() {
//		return farmer_Name;
//	}
//
//
//	public void setFarmer_Name(String farmer_Name) {
//		this.farmer_Name = farmer_Name;
//	}
//
//
//	public String getFarmer_Email() {
//		return farmer_Email;
//	}
//
//
//	public void setFarmer_Email(String farmer_Email) {
//		this.farmer_Email = farmer_Email;
//	}
//
//
//	public String getFlag() {
//		return flag;
//	}
//
//
//	public void setFlag(String flag) {
//		this.flag = flag;
//	}
//
//	
//	
//}
