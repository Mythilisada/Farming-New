import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/Beans/User';
import { Crop } from 'src/Beans/Crop';
@Injectable({
  providedIn: 'root'
})
export class FarmerServiceService {


  url="http://localhost:8080/farming";
  http: HttpClient;
  router:Router;
  users:User[]=[];
  flagUser:boolean=false;
  crops:Crop[]=[];
  flagCrop:boolean=false;
  constructor(http:HttpClient, router:Router) {
    this.http = http;
    this.router=router;
    this.fetchUser();
    console.log(this.users);
    this.fetchProductRequirements();
    console.log(this.crops);
   }

  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }

  //Farmer Registration 
  addUser(users):Promise<any>{
    window.alert("Registered Successfully");
    return this.http.post(this.url+"/createuser",users)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
  }


  //Login Farmer
  getValidation(email, password) {
      return this.http.get(this.url+"/login/"+email+"/"+password)
  }

  //View Product Requirements
  fetchProductRequirements(){
    return this.http.get(this.url+"/viewproductrequirements")
  }

  //View User
  fetchUser(){
    return this.http.get(this.url+"/fetchusers");
  }

}
