import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FarmeHomeComponent } from './farme-home.component';

describe('FarmeHomeComponent', () => {
  let component: FarmeHomeComponent;
  let fixture: ComponentFixture<FarmeHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FarmeHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FarmeHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
