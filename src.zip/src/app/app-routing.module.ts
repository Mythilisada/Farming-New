import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FarmerLoginComponent } from './farmer-login/farmer-login.component';
import { AppComponent } from './app.component';
import { FarmerRegisterComponent } from './farmer-register/farmer-register.component';
import { FarmeHomeComponent } from './farme-home/farme-home.component';
import { ViewProductRequirementComponent } from './view-product-requirement/view-product-requirement.component';
import { ViewUsersComponent } from './view-users/view-users.component';


const routes: Routes = [

  {
    path:"farmerLogin",
    component: FarmerLoginComponent
  },
  {
    path:"farmerRegister",
    component: FarmerRegisterComponent
  },
  {
    path:"farmerHome",
    component: FarmeHomeComponent
  },
  {
    path:"productRequirements",
    component: ViewProductRequirementComponent
  },
  {
    path:"viewUsers",
    component: ViewUsersComponent
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
