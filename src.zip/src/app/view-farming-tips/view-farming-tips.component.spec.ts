import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewFarmingTipsComponent } from './view-farming-tips.component';

describe('ViewFarmingTipsComponent', () => {
  let component: ViewFarmingTipsComponent;
  let fixture: ComponentFixture<ViewFarmingTipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewFarmingTipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewFarmingTipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
