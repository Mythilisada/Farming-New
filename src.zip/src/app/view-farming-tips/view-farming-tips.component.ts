import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-farming-tips',
  templateUrl: './view-farming-tips.component.html',
  styleUrls: ['./view-farming-tips.component.css']
})
export class ViewFarmingTipsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
