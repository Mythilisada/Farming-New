import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Books } from '../beans/Books';
import { LibraryServiceService } from '../library-service.service';
@Component({
  selector: 'app-add-books',
  templateUrl: './add-books.component.html',
  styleUrls: ['./add-books.component.css']
})
export class AddBooksComponent implements OnInit {
  [ x: string]: any;
  book:Books;
  createdFlag:boolean=false;
  library:LibraryServiceService;
  router:Router;
  constructor(library:LibraryServiceService,router:Router) { 
    this.library=library;
    this.router=router;
  }

  ngOnInit(): void {
  }

  addBook(data:any){
    let book=new Books(data.book_Id,data.book_Name,data.book_Author,data.book_Description,data.book_Amount,data.book_Total,data.book_Available);
    this.library.addBook(book).then(response=>{
      this.router.navigateByUrl('viewBookPage');
    },
    err=>{
      if (err.success != undefined && err.success == false) {
        alert(err.errors);
        }
    });
  }

}
