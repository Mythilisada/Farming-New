import { Component, OnInit } from '@angular/core';
import { LibraryServiceService } from '../library-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {

  library:LibraryServiceService;
  router:Router;
  constructor(library:LibraryServiceService,router:Router) {
    this.library=library;
    this.router=router;
   }

  ngOnInit(): void {
  }

  forgotPassword(data:any){
    let result:boolean;
    this.library.forgotPassword(data);
  }

}
