import { Component, OnInit } from '@angular/core';
//import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { LibraryServiceService } from '../library-service.service';
import { User } from '../beans/User';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  router: Router;
  users:User;
  userFlag:boolean=false;
  library:LibraryServiceService;
  //form:FormGroup;
  model: any = {};
  constructor(library:LibraryServiceService,router:Router) {
    this.library=library;
    this.router=router;
   }

  signUp(data:any){
     let users=new User(data.user_Id,data.user_Name,data.user_Password,data.user_ReEnterPassword,
      data.user_Email,data.user_MobileNumber,data.user_HomeAddress,data.user_Question,
      data.user_Answer);
    this.library.addUser(users).then(response=>{
    this.router.navigateByUrl('loginPage');
    },
    err=>{
      if (err.success != undefined && err.success == false) {
        alert(err.errors);
        }
    });
  }

  ngOnInit(): void {

    }
}
 
