import { Component, OnInit } from '@angular/core';
import { LibraryServiceService } from '../library-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user_Email=''
  user_Password=''
  invalidLogin=false
  library:LibraryServiceService;
  router:Router;

  constructor(router:Router,library:LibraryServiceService){
    this.library=library;
    this.router=router;
  }

  ngOnInit(): void {
  }


  checkLogin(data:any){ 
    var encryptuserId = (user_Id): number => {
      var genereatedId = parseInt(user_Id) - 500000;
      return genereatedId;
    }

  if(this.library.loginAccount(data)){
    let encryptUserId = encryptuserId(data.user_Id);
    //this.auth.sendToken(encryptUserId.toString());
  }
  }
  
}
