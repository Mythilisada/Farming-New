import { Component, OnInit } from '@angular/core';
import { LibraryServiceService } from '../library-service.service';
import { Books } from '../beans/Books';

@Component({
  selector: 'app-view-books',
  templateUrl: './view-books.component.html',
  styleUrls: ['./view-books.component.css']
})
export class ViewBooksComponent implements OnInit {

  library:LibraryServiceService;
  book:Books[]=[];
  constructor(library:LibraryServiceService) { 
    this.library=library;
  }
 

  ngOnInit(): void {

    this.library.fetchBook().subscribe(data => this.book = data);
  }

}
