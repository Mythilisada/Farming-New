import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LibraryServiceService } from '../library-service.service';

@Component({
  selector: 'app-orderbook',
  templateUrl: './orderbook.component.html',
  styleUrls: ['./orderbook.component.css']
})
export class OrderbookComponent implements OnInit {
  router:Router;
  library:LibraryServiceService;
  constructor(router:Router,library:LibraryServiceService) { 
    this.library=library;
    this.router=router;
  }

  ngOnInit(): void {
  }

  order(data:any){
    this.library.orderbooks(data);
      }

}
