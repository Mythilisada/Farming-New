export class Admin {

    admin_Id: number;
    admin_Name: string;
    admin_Password: string;


    constructor(admin_Id: number,
        admin_Name: string,
        admin_Password: string,
    ) {
        this.admin_Id = admin_Id;
        this.admin_Name = admin_Name;
        this.admin_Password = admin_Password;


    }
}