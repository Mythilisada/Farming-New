export class User {

    user_Id: number;
    user_Name: string;
    user_Password: string;
    user_ReEnterPassword:string;
    user_Email: string;
    user_MobileNumber:string;
    user_HomeAddress: string;
    user_Question: string;
    user_Answer: string;
    

    constructor(user_Id: number,
        user_Name: string,
        user_Password: string,
        user_ReEnterPassword:string,
        user_Email: string,
        user_MobileNumber:string,
        user_HomeAddress: string,
        user_Question: string,
        user_Answer: string)
    {
        this.user_Id = user_Id;
        this.user_Name = user_Name;
        this.user_Password = user_Password;
        this.user_ReEnterPassword=user_ReEnterPassword;
        this.user_Email=user_Email;
        this.user_MobileNumber = user_MobileNumber;
        this.user_HomeAddress = user_HomeAddress;
        this.user_Question = user_Question;
        this.user_Answer = user_Answer;

    }
}