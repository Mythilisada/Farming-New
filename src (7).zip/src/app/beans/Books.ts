export class Books{
    book_Id:number;
    book_Name:string;
    book_Author:string;
    book_Description:string;
    book_Amount:number;
    book_Total:number;
    book_Available:number;

    constructor(book_Id:number,book_Name:string,book_Author:string,book_Description:string,book_Amount:number,book_Total:number,book_Available:number){
    this.book_Id=book_Id;
    this.book_Name=book_Name;
    this.book_Author=book_Author;
    this.book_Description=book_Description;
    this.book_Amount=book_Amount;
    this.book_Total=book_Total;
    this.book_Available=book_Available;
    }
}