import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { ForgotComponent } from './forgot/forgot.component';
import { LogoutComponent } from './logout/logout.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddBooksComponent } from './add-books/add-books.component';
import { ViewBooksComponent } from './view-books/view-books.component';
import { BooksComponent } from './books/books.component';
import { UsersComponent } from './users/users.component';
import { ViewUsersComponent } from './view-users/view-users.component';
import { DeletebookComponent } from './deletebook/deletebook.component';
import { OrderbookComponent } from './orderbook/orderbook.component';


const routes: Routes = [
//   {
//   path:'',
//   component:HomepageComponent,
//   pathMatch: 'full'
// },
{
  path: 'loginPage',
  component: LoginComponent},
{
  path:'registerPage',
  component: RegisterComponent
},
{
  path:'userPage',
  component: UserHomeComponent
},
{
  path:'adminPage',
  component:AdminHomeComponent
},
{
  path:'bookPage',
  component:BooksComponent
},
{
  path:'userAPage',
  component:UsersComponent
},
{
  path:'addBookPage',
  component:AddBooksComponent
},
{
  path:'viewBookPage',
  component:ViewBooksComponent
},
{
  path:'orderBookPage',
  component:OrderbookComponent
},
{
  path:'deleteBookPage',
  component:DeletebookComponent
},
{
  path:'viewUserPage',
  component:ViewUsersComponent
},
{
  path:'logoutPage',
  component:LogoutComponent
},
{
  path:'forgotPage',
  component: ForgotComponent
},
{
  path:'changePasswordPage',
  component:ChangePasswordComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
