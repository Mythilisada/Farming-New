import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LibraryServiceService } from '../library-service.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  router:Router;
  library:LibraryServiceService;

  constructor(router:Router,library:LibraryServiceService) { 
    this.router=router;
    this.library=library;
  }

  ngOnInit(): void {
  }

  changePassword(data:any){
    this.library.changePassword(data);
    
      }

}
