import { Component, OnInit } from '@angular/core';
import { LibraryServiceService } from '../library-service.service';
import { User } from '../beans/User';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.css']
})
export class ViewUsersComponent implements OnInit {
  library:LibraryServiceService;
  users:User[]=[];
  constructor(library:LibraryServiceService) { 
    this.library=library;
  }

  ngOnInit(): void {
    this.library.fetchUser().subscribe(data => this.users = data);
  }

}
