import { Component, OnInit } from '@angular/core';
import { LibraryServiceService } from '../library-service.service';
import { Books } from '../beans/Books';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deletebook',
  templateUrl: './deletebook.component.html',
  styleUrls: ['./deletebook.component.css']
})
export class DeletebookComponent implements OnInit {
  library:LibraryServiceService;
  book:Books[]=[];
  status;
  column:string="book_Id";
  order:boolean=true;
  sort(column:string)
  {
    if(this.column==column)
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column;
    }
  }
  constructor( private router: Router ,library:LibraryServiceService) { 
    this.library=library;
  }
  deleteBook(book_Id:number){
    this.library.deleteBook(book_Id).subscribe(data=>this.status=data);
    this.library.fetchBook().subscribe(data => this.book = data);
    this.router.navigateByUrl('deleteBookPage');
    }

  ngOnInit(): void {
    this.library.fetchBook().subscribe(data => this.book = data);
  }


}
