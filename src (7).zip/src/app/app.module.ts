import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ForgotComponent } from './forgot/forgot.component';
import { RegisterComponent } from './register/register.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { HomepageComponent } from './homepage/homepage.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddBooksComponent } from './add-books/add-books.component';
import { ViewBooksComponent } from './view-books/view-books.component';
import { ViewUsersComponent } from './view-users/view-users.component';
import { BooksComponent } from './books/books.component';
import { UsersComponent } from './users/users.component';
import { LibraryServiceService } from './library-service.service';
import { DeletebookComponent } from './deletebook/deletebook.component';
import { SortPipe } from './sort.pipe';
import { OrderbookComponent } from './orderbook/orderbook.component';
import { VieworderComponent } from './vieworder/vieworder.component';


//import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LogoutComponent,
    ForgotComponent,
    RegisterComponent,
    UserHomeComponent,
    HomepageComponent,
    DashboardComponent,
    ChangePasswordComponent,
    AdminHomeComponent,
    AddBooksComponent,
    ViewBooksComponent,
    ViewUsersComponent,
    BooksComponent,
    UsersComponent,
    DeletebookComponent,
    SortPipe,
    OrderbookComponent,
    VieworderComponent

  ],
  imports: [
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    //NgxSpinnerModule,
    ReactiveFormsModule
    
  ],
  providers: [HttpClient,LibraryServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }



