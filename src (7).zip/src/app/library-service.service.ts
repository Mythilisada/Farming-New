import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Admin } from './beans/Admin';
import { User } from './beans/User';
import { Books } from './beans/Books';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class LibraryServiceService {
  url="http://localhost:1999/library";
  http: HttpClient;
  router:Router;
  admins: Admin[] = [];
  flagAdmin:boolean=false;
  users:User[]=[];
  flagUser:boolean=false;
  book:Books[]=[];
  flagBook:boolean=false;

  constructor(http: HttpClient,router:Router) { 
    this.http = http;
    this.router=router;
    this.fetchAdmin();
    console.log(this.admins);
    this.fetchUser();
    console.log(this.users);
    this.fetchBook();
    console.log(this.book);
  }


  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }

  //Admin
  fetchAdmin():Observable<Admin[]>{
    return this.http.get<Admin[]>
    (this.url+"/fetchalladmin");
  }

  
  //Login User or Admin
  loginAccount(data:any):boolean{
    for(let a of this.admins){
      if(a.admin_Name==data.user_Email && a.admin_Password==data.user_Password){
        alert("You are Admin:-)\n Your Account Id is:"+a.admin_Id)
        this.flagAdmin=true;
        this.router.navigate(['dashboard']);
        return true;
      }else{
        for(let u of this.users){
          if(u.user_Email==data.user_Email && u.user_Password==data.user_Password){
            alert("You are Admin:-)\n Your Account Id is:"+u.user_Id)
            this.flagUser=true;
            this.router.navigate(['dashboard']);
            return true;
          }
      }
      }
    }
  if(this.flagAdmin==false||this.flagUser==false){
    alert("Invalid Credentials")
  }else{
    alert("Login Successfull:-)")
  }
}


  //User

  //Add User
  addUser(users):Promise<any>{
    window.alert("Added Successfully");
    return this.http.post(this.url+"/createuser",users)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
  }

  //Fetch User
  fetchUser():Observable<User[]>{
    return this.http.get<User[]>
    (this.url+"/fetchalluser");
  }


  //Forgot Password
  forgotPassword(data:any){
    this.http.put('http://localhost:1999/library/forgotpassword/'
    +data.user_Id
    +"/"+data.user_Question
    +"/"+data.user_Answer
    +"/"+data.user_Password,null).subscribe((data)=>
    {
      alert("Password Changed Successfully (U):-)")
      this.router.navigate(['/loginPage'])
    },(errorU)=>{
      console.log(errorU.error.message)
      alert(errorU.error.message)
    })
  }

  //Change Password
  changePassword(data:any){
    this.http.put('http://localhost:1999/library/changepassword/'
    +data.user_Id
    +"/"+data.old_Password
    +"/"+data.new_Password,
    null).subscribe((data)=>{
      alert("Password Changed Successfully (U):-)")
      this.router.navigate(['/loginPage'])
    },(errorU)=>{
      console.log(errorU.error.message)
      alert(errorU.error.message)
    })
  }


  //Book Functions
  //Add Books
addBook(books):Promise<any>{
  window.alert("Added Successfully");
  return this.http.post(this.url+"/addbooks/",books)
  .toPromise()
  .then(response => response)
  .catch(this.handleError);
  }

  //View Books
  fetchBook():Observable<Books[]>{
    return this.http.get<Books[]>
    (this.url+"/fetchallbooks");
  }

  //Delete Books
  deleteBook(book_Id:number){
    return this.http.delete(this.url + '/deletebook/'+book_Id);
    //this.router.navigateByUrl('Merchant Notification');
  }

  //Order Books
  orderbooks(data:any){

  }
}

