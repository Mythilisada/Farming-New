package com.cap.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.User;

@Repository
public interface UserRepo extends JpaRepository<User,Long>{
	
	//login
	@Query("from User where user_Email=?1")
	public User loginByuserEmail(String user_Email,String user_Password);
	
}
