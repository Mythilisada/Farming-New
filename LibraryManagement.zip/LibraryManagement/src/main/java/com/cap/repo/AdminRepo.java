package com.cap.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.Admin;

@Repository
public interface AdminRepo extends JpaRepository<Admin, Long> {
	
	@Query("from Admin where admin_Name=?1")
	public Admin adminLogin(String admin_Name,String admin_Password);
}
