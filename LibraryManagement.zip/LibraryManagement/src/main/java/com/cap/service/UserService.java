package com.cap.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cap.entities.User;

@Service
public interface UserService {
		
		//User Registration
		public User createUserAccount(User userReg);
		
		//User Login
		public User loginByuserEmail(String user_Email,String user_Password);
		
		//Forgot Password
		public boolean forgotPassword(long user_Id,String user_Question,String user_Answer,String user_Password);
		
		//Update Password
		public boolean changePassword(long user_Id, String old_Password,String new_Password);
		
		//Edit Profile
		public boolean edituserProfile(long user_Id, String user_Name, String user_HomeAddress,
				String user_MobileNumber);
		
		//Fetch User Details By Id
		public User fetchUserById(long user_Id);
		
		//Fetch All User Details
		public List<User> fetchAllUser();

		
}
