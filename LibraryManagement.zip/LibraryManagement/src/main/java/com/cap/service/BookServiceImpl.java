package com.cap.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.entities.Books;
import com.cap.entities.Order;
import com.cap.repo.BookRepo;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookRepo repo;

	// Book Registration
	public Books addBooks(Books bookReg) {
		List<Books> books = repo.findAll();
		Iterator<Books> itr = books.iterator();
		while (itr.hasNext()) {
			Books book = itr.next();
			// System.out.println(book.getBook_Name());
			if (book.getBook_Name().equals(bookReg.getBook_Name())) {
				// System.out.println(book.getBook_Name());
				int count = book.getBook_Total();
				// System.out.println(count);
				count = count + 1;
				// System.out.println(count);
				bookReg.setBook_Total(count);
				/*
				 * Order ordered=book.getOrder(); long available_Book=ordered.getOrder_Id()-1;
				 * bookReg.setBook_Available(available_Book);
				 */
				break;
			} else {
				int book_Total = 1;
				bookReg.setBook_Total(book_Total);
			}
		}
		repo.save(bookReg);
		return bookReg;
	}

	// Fetch All Book Details
	public List<Books> fetchAllBook() {
		return repo.findAll();
	}

	// Delete Books By Id
	public List<Books> deleteBook(long book_Id) {
		repo.deleteById(book_Id);
		List<Books> book = repo.findAll();
		return book;
	}
	
	
}
