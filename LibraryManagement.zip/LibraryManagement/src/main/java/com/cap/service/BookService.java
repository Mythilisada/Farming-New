package com.cap.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cap.entities.Books;

@Service
public interface BookService {

	//Book Registration
		public Books addBooks(Books bookReg);
		
	//Fetch All Book Details
		public List<Books> fetchAllBook();
		
	//Delete Books By Id
		public List<Books> deleteBook(long book_Id);
		

}
