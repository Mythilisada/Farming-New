package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.entities.Admin;
import com.cap.exception.LibraryException;
import com.cap.repo.AdminRepo;
import com.cap.util.Decryption;
import com.cap.util.Encryption;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	AdminRepo repo;
	
		// Admin Login
		public Admin adminLogin(String admin_Name,String admin_Password) {
			Admin admin=repo.adminLogin(admin_Name,admin_Password);
			String adminName=admin.getAdmin_Name();
			String admin_Passwd=(Decryption.decrypt(admin.getAdmin_Password()));
			if(adminName.equals(admin_Name)&&admin_Passwd.equals(admin_Password)) {
				System.out.println("Login Successfully");
				return admin;
			}else {
				return null;
			}
		}


		//Admin SignUp
		public Admin createAdminAccount(Admin admin) {
			if (admin == null) {
				throw new LibraryException("User Account is Not Created. Please fill the required fields");
			} else {
				admin.setAdmin_Password(Encryption.encrypt(admin.getAdmin_Password()));
				repo.save(admin);
				return admin;
			}
			
		}
		
		//Fetch Admin Details By ID
		public Admin fetchByAdminId(long admin_Id) {
			Admin admin=repo.findById(admin_Id).get();
			return admin;
			
		}
		
		
		//Fetch All Admin Details
		public List<Admin> fetchAllAdmin(){
			List<Admin> admin=repo.findAll();
			return admin;
		}
		
}
