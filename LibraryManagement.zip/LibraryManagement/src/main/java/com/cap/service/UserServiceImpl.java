package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.entities.User;
import com.cap.exception.LibraryException;
import com.cap.exception.UserCreationException;
import com.cap.repo.UserRepo;
import com.cap.util.Decryption;
import com.cap.util.Encryption;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo repo;

	// User Registration
	public User createUserAccount(User userReg) throws UserCreationException{

		if (userReg == null) {
			throw new UserCreationException("User Account is Not Created. Please fill the required fields");
		} else {
			userReg.setUser_Password(Encryption.encrypt(userReg.getUser_Password()));
			userReg.setUser_ReEnterPassword(Encryption.encrypt(userReg.getUser_ReEnterPassword()));
			repo.save(userReg);
			return userReg;
		}
		
	}

	// User Login
	public User loginByuserEmail(String user_Email, String user_Password) {
		
		User user = repo.loginByuserEmail(user_Email, user_Password);
		String user_Mail = user.getUser_Email();
		String user_passwd = (Decryption.decrypt(user.getUser_Password()));
		//System.out.println(user_Email+" "+user_Password);
		//System.out.println(user_Mail+" "+user_passwd);
		if (user_Mail.equals(user_Email) && user_passwd.equals(user_Password)) {
			System.out.println("Login Successfully");
			return user;
		} else {
			return null;
		}
	}

	// Forgot Password
	public boolean forgotPassword(long user_Id,String user_Question,String user_Answer,String user_Password) throws LibraryException{
		//try{
		Optional<User> optional=repo.findById(user_Id);
		if(optional.isPresent()) {
			//System.out.println(user_Id+" "+user_Question+" "+user_Answer+" "+user_Password);
			if(optional.get().getUser_Question().equalsIgnoreCase(user_Question) && optional.get().getUser_Answer().equalsIgnoreCase(user_Answer)) {
			User user=optional.get();
			user.setUser_Password(Encryption.encrypt(user_Password));
			user.setUser_ReEnterPassword(Encryption.encrypt(user_Password));
			repo.save(user);
			return true;
			}
			else {
				throw new LibraryException("Please enter the correct answer for that question.");
			}
		}else {
			throw new LibraryException("Account ID does not exist.");
			}
		//}	
	}
	
	
	// Update Password
	public boolean changePassword(long user_Id, String old_Password,String new_Password) {
		Optional<User> optional=repo.findById(user_Id); 
		//System.out.println(user_Id+" "+old_Password+" "+new_Password);
		if(optional.isPresent()) {
			if(Decryption.decrypt(optional.get().getUser_Password()).equals(old_Password)) {
					User user=optional.get();
					user.setUser_Password(Encryption.encrypt(new_Password));
					user.setUser_ReEnterPassword(Encryption.encrypt(new_Password));
					repo.save(user);
					return true;
					}
					else {
						throw new LibraryException("Please enter the old password correctly.");
					}
				}else {
					throw new LibraryException("Account ID does not exist.");
					}
		}
		
	

	// Update User Profile
	public boolean edituserProfile(long user_Id, String user_Name, String user_HomeAddress,
			String user_MobileNumber) {
		Optional<User> optional=repo.findById(user_Id); 
		if(optional.isPresent()) {
					User user=optional.get();
					user.setUser_Name(user_Name);
					user.setUser_HomeAddress(user_HomeAddress);
					user.setUser_MobileNumber(user_MobileNumber);
					repo.save(user);
					return true;
					}
				else {
					throw new LibraryException("Account ID does not exist.");
					}	
}

	//Fetch User Details By Id
	public User fetchUserById(long user_Id) {
		User user=repo.findById(user_Id).get();
		return user;
	}
	
	
	//Fetch All User Details
	public List<User> fetchAllUser(){
		List<User> user=repo.findAll();
		return user;
	}
}
