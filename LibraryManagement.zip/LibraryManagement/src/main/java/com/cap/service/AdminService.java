package com.cap.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cap.entities.Admin;

@Service
public interface AdminService {
	//Admin SignUp
	public Admin createAdminAccount(Admin admin);
	
	//Admin Login
	public Admin adminLogin(String admin_Name,String admin_Password);
	
	//Fetch Admin Details By ID
	public Admin fetchByAdminId(long admin_Id);
	
	//Fetch All Admin Details
	public List<Admin> fetchAllAdmin();

}
