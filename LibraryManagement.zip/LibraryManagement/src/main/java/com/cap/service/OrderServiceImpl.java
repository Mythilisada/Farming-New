package com.cap.service;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.entities.Books;
import com.cap.entities.Order;
import com.cap.repo.OrderRepo;
@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepo repo;

	public Order orderBook(Order order) {
		String order_BookName=order.getBook_Name();
		/*
		 * Iterator<Books> itr = books.iterator(); while (itr.hasNext()) { Books book =
		 * itr.next(); if(book_Name.equals(order_BookName)) { long
		 * available_Books=book.getBook_Total()-1;
		 * book.setBook_Available(available_Books);
		 * System.out.println("Order Successfull"); }else {
		 * System.out.println("Order is not placed"); }
		 */
		return order;
	}
}
