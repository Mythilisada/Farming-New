package com.cap.exception;

@SuppressWarnings("serial")
public class LibraryException extends RuntimeException{
	
	public LibraryException(String errMsg) {
		super(errMsg);
	}
	
	public LibraryException() {
		super();
	}

	
}
