package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Admin;
import com.cap.entities.Books;
import com.cap.entities.User;
import com.cap.exception.LibraryException;
import com.cap.service.AdminService;
import com.cap.service.BookService;
import com.cap.service.UserService;
  
@CrossOrigin(origins = "*") 
@RestController
@RequestMapping("/library")
public class LibraryController {

	@Autowired
	AdminService admin_Service;
	
	@Autowired
	UserService user_Service;
	
	@Autowired
	BookService book_Service;
	
	
	//Admin Functions
	
	@PostMapping("/createadmin")
	public Admin createAdminAccount(@RequestBody Admin admin){
		return admin_Service.createAdminAccount(admin);
	}
	
	@GetMapping("/adminlogin/{admin_Name}/{admin_Password}")
	public Admin adminLogin(@PathVariable String admin_Name,@PathVariable String admin_Password) {
		return admin_Service.adminLogin(admin_Name,admin_Password);
	}
	
	@GetMapping("/fetchadmin/{admin_Id}")
	public Admin fetchByAdminId(@PathVariable long admin_Id) {
		return admin_Service.fetchByAdminId(admin_Id);
	}
	
	@GetMapping("/fetchalladmin")
	public List<Admin> fetchAllAdmin() {
		return admin_Service.fetchAllAdmin();
	}
	
	//User Functions
	
	@PostMapping("/createuser")
	public User createUserAccount(@RequestBody User userReg){
		return user_Service.createUserAccount(userReg);
	}

	@GetMapping("/login/{user_Email}/{user_Password}")
	public User loginByuserEmail(@PathVariable String user_Email, @PathVariable String user_Password) {
		return user_Service.loginByuserEmail(user_Email, user_Password);
	}

	@PutMapping("/forgotpassword/{user_Id}/{user_Question}/{user_Answer}/{user_Password}")
	public boolean forgotPassword(@PathVariable long user_Id, @PathVariable String user_Question,
			@PathVariable String user_Answer, @PathVariable String user_Password) throws LibraryException{
		return user_Service.forgotPassword(user_Id, user_Question, user_Answer, user_Password);
	}

	@PutMapping("/changepassword/{user_Id}/{old_Password}/{new_Password}")
	public boolean changePassword(@PathVariable long user_Id,@PathVariable String old_Password,@PathVariable String new_Password) {
		return user_Service.changePassword(user_Id,old_Password,new_Password);
	}

	@PutMapping("/editprofile/{user_Id}/{user_Name}/{user_HomeAddress}/{user_MobileNumber}")
	public boolean edituserProfile(@PathVariable long user_Id,@PathVariable String user_Name,@PathVariable String user_HomeAddress,
			@PathVariable String user_MobileNumber) {
		return user_Service.edituserProfile(user_Id, user_Name, user_HomeAddress, user_MobileNumber);
	}
	
	@GetMapping("/fetchuser/{user_Id}")
	public User fetchByUserId(@PathVariable long user_Id) {
		return user_Service.fetchUserById(user_Id);
	}
	
	@GetMapping("/fetchalluser")
	public List<User> fetchAllUser() {
		return user_Service.fetchAllUser();
	}
	
	//Book Functions
	@PostMapping("/addbooks")
	public Books addBooks(@RequestBody Books bookReg) {
		return book_Service.addBooks(bookReg);
	}
	
	//Fetch All Book Details
	@GetMapping("/fetchallbooks")
	public List<Books> fetchAllBook(){
		return book_Service.fetchAllBook();
	}
	
	//Delete Books By Id
	@DeleteMapping("/deletebook/{book_Id}")
	public List<Books> deleteBook(@PathVariable long book_Id){
		return book_Service.deleteBook(book_Id);
	}
	

}
