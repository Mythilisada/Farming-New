package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="UserLib")
public class User {
	@Id
	@GeneratedValue
	@Column(length=20)
	private long user_Id;
	
	@Column(length=20)
	@NotNull
	private String user_Name;
	
	@Column(length=50)
	@NotNull
	private String user_Password;
	
	@Column(length=50)
	@NotNull
	private String user_ReEnterPassword;
	
	@Column(length=50,unique=true)
	private String user_Email;
	
	@Column(length=10,unique=true)
	private String user_MobileNumber;
	
	@Column(length=100)
	@NotNull
	private String user_HomeAddress;
	
	@Column(length=50)
	@NotNull
	private String user_Question;
	
	@Column(length=50)
	@NotNull
	private String user_Answer;

	public long getUser_Id() {
		return user_Id;
	}

	public void setUser_Id(long user_Id) {
		this.user_Id = user_Id;
	}

	public String getUser_Name() {
		return user_Name;
	}

	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}

	public String getUser_Password() {
		return user_Password;
	}

	public void setUser_Password(String user_Password) {
		this.user_Password = user_Password;
	}

	public String getUser_ReEnterPassword() {
		return user_ReEnterPassword;
	}

	public void setUser_ReEnterPassword(String user_ReEnterPassword) {
		this.user_ReEnterPassword = user_ReEnterPassword;
	}

	public String getUser_Email() {
		return user_Email;
	}

	public void setUser_Email(String user_Email) {
		this.user_Email = user_Email;
	}

	public String getUser_MobileNumber() {
		return user_MobileNumber;
	}

	public void setUser_MobileNumber(String user_MobileNumber) {
		this.user_MobileNumber = user_MobileNumber;
	}

	public String getUser_HomeAddress() {
		return user_HomeAddress;
	}

	public void setUser_HomeAddress(String user_HomeAddress) {
		this.user_HomeAddress = user_HomeAddress;
	}

	public String getUser_Question() {
		return user_Question;
	}

	public void setUser_Question(String user_Question) {
		this.user_Question = user_Question;
	}

	public String getUser_Answer() {
		return user_Answer;
	}

	public void setUser_Answer(String user_Answer) {
		this.user_Answer = user_Answer;
	}

	public User(long user_Id, @NotNull String user_Name, @NotNull String user_Password,
			@NotNull String user_ReEnterPassword, String user_Email, String user_MobileNumber,
			@NotNull String user_HomeAddress, @NotNull String user_Question, @NotNull String user_Answer) {
		super();
		this.user_Id = user_Id;
		this.user_Name = user_Name;
		this.user_Password = user_Password;
		this.user_ReEnterPassword = user_ReEnterPassword;
		this.user_Email = user_Email;
		this.user_MobileNumber = user_MobileNumber;
		this.user_HomeAddress = user_HomeAddress;
		this.user_Question = user_Question;
		this.user_Answer = user_Answer;
	}

	public User() {
		super();
	}

	@Override
	public String toString() {
		return "User [user_Id=" + user_Id + ", user_Name=" + user_Name + ", user_Password=" + user_Password
				+ ", user_ReEnterPassword=" + user_ReEnterPassword + ", user_Email=" + user_Email
				+ ", user_MobileNumber=" + user_MobileNumber + ", user_HomeAddress=" + user_HomeAddress
				+ ", user_Question=" + user_Question + ", user_Answer=" + user_Answer + "]";
	}
	
	
	
	
	/*
	 * @Column(length=10)
	 * 
	 * @NotNull private String user_Status="inactive";
	 */
	 

}
