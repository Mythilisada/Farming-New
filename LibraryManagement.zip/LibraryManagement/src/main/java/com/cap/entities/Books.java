
package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "book_lib")
public class Books {

	@Id
	@Column(length=20)
	private long book_Id;

	@Column(length=50)
	private String book_Name;

	@Column(length=20)
	private String book_Author;

	@Column(length=50)
	private String book_Description;
	
	@Column(length=10)
	private int book_Amount;

	@Column(length=10)
	private int book_Total;

	@Column(length=10)
	private long book_Available;
	
	  @OneToOne
	  @JoinTable(name = "order_lib")
	  private Order order;

	public long getBook_Id() {
		return book_Id;
	}

	public void setBook_Id(long book_Id) {
		this.book_Id = book_Id;
	}

	public String getBook_Name() {
		return book_Name;
	}

	public void setBook_Name(String book_Name) {
		this.book_Name = book_Name;
	}

	public String getBook_Author() {
		return book_Author;
	}

	public void setBook_Author(String book_Author) {
		this.book_Author = book_Author;
	}

	public String getBook_Description() {
		return book_Description;
	}

	public void setBook_Description(String book_Description) {
		this.book_Description = book_Description;
	}

	public int getBook_Amount() {
		return book_Amount;
	}

	public void setBook_Amount(int book_Amount) {
		this.book_Amount = book_Amount;
	}

	public int getBook_Total() {
		return book_Total;
	}

	public void setBook_Total(int book_Total) {
		this.book_Total = book_Total;
	}

	public long getBook_Available() {
		return book_Available;
	}

	public void setBook_Available(long book_Available) {
		this.book_Available = book_Available;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Books(long book_Id, String book_Name, String book_Author, String book_Description, int book_Amount,
			int book_Total, long book_Available, Order order) {
		super();
		this.book_Id = book_Id;
		this.book_Name = book_Name;
		this.book_Author = book_Author;
		this.book_Description = book_Description;
		this.book_Amount = book_Amount;
		this.book_Total = book_Total;
		this.book_Available = book_Available;
		this.order = order;
	}

	public Books() {
		super();
	}

	@Override
	public String toString() {
		return "Books [book_Id=" + book_Id + ", book_Name=" + book_Name + ", book_Author=" + book_Author
				+ ", book_Description=" + book_Description + ", book_Amount=" + book_Amount + ", book_Total="
				+ book_Total + ", book_Available=" + book_Available + ", order=" + order + "]";
	}

	
	
	
	

}
