package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_lib")
public class Admin {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long admin_Id;
	@Column(length = 30)
	private String admin_Name;
	@Column(length = 30)
	private String admin_Password;

	public Admin() {
		super();
	}

	public Admin(long admin_Id, String admin_Name, String admin_Password) {
		super();
		this.admin_Id = admin_Id;
		this.admin_Name = admin_Name;
		this.admin_Password = admin_Password;
	}

	public long getAdmin_Id() {
		return admin_Id;
	}

	public void setAdmin_Id(long admin_Id) {
		this.admin_Id = admin_Id;
	}

	public String getAdmin_Name() {
		return admin_Name;
	}

	public void setAdmin_Name(String admin_Name) {
		this.admin_Name = admin_Name;
	}

	public String getAdmin_Password() {
		return admin_Password;
	}

	public void setAdmin_Password(String admin_Password) {
		this.admin_Password = admin_Password;
	}

	@Override
	public String toString() {
		return "Admin [admin_Id=" + admin_Id + ", admin_Name=" + admin_Name + ", admin_Password=" + admin_Password
				+ "]";
	}

}