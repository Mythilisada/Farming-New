package com.cap.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="order_lib")
public class Order {
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator =
	  "order_seq_gen")
	  @SequenceGenerator(name = "order_seq_gen", initialValue = 10000, sequenceName
	  = "order_seq") 
	  private long order_Id; 
	  
	  @Column(length=20)
	  private String user_Name;
	  
	/*
	 * @OneToOne
	 * 
	 * @JoinTable(name = "book_lib") private Books book;
	 */
	  @Column(length=50)
	  private String book_Name;
	  
	  @Column
	  private double due_Amount;
	  
	  @Column
	  private Date issue_Date;
	  
	  @Column
	  private Date due_Date;

	public long getOrder_Id() {
		return order_Id;
	}

	public void setOrder_Id(long order_Id) {
		this.order_Id = order_Id;
	}

	public String getUser_Name() {
		return user_Name;
	}

	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}
	public String getBook_Name() {
		return book_Name;
	}

	public void setBook_Name(String book_Name) {
		this.book_Name = book_Name;
	}

	public double getDue_Amount() {
		return due_Amount;
	}

	public void setDue_Amount(double due_Amount) {
		this.due_Amount = due_Amount;
	}

	public Date getIssue_Date() {
		return issue_Date;
	}

	public void setIssue_Date(Date issue_Date) {
		this.issue_Date = issue_Date;
	}

	public Date getDue_Date() {
		return due_Date;
	}

	public void setDue_Date(Date due_Date) {
		this.due_Date = due_Date;
	}

	public Order(long order_Id, String user_Name,String book_Name, double due_Amount, Date issue_Date, Date due_Date) {
		super();
		this.order_Id = order_Id;
		this.user_Name = user_Name;
		this.book_Name = book_Name;
		this.due_Amount = due_Amount;
		this.issue_Date = issue_Date;
		this.due_Date = due_Date;
	}

	public Order() {
		super();
	}

	@Override
	public String toString() {
		return "Order [order_Id=" + order_Id + ", user_Name=" + user_Name + ", book_Name=" + book_Name + ",due_Amount=" + due_Amount
				+ ", issue_Date=" + issue_Date + ", due_Date=" + due_Date + "]";
	}
	    
	 
}
